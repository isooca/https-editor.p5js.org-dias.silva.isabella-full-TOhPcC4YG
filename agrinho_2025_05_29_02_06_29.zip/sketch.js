// definindo variáveis globais
let boneco;
let plantas = [];
let temperatura = 10;
let totalArvores = 0;

function setup() {
  createCanvas(400, 400);
  boneco = new jardineiro(width / 2, height - 50);
}

function draw() {
  // usando map() para ajustar a cor do fundo de forma mais controlada
  let corFundo = lerpColor(color(217, 112, 26), color(209, 239, 208));
                          map(TotalÁrvores, 0, 100, 0, 1));
                          
  background(corFundo);
  mostrarinformações();

  temperatura += 0.1;

  jardineiro.atualizar();
  jardineiro.mostrar();

  //verifica se o jogo cabou
  verificarFimdeJogo();

  //usando map() para aplicar o comportamento das arvores plantadas
  plantas.map((arvore) => arvore.mostrar());
}

//funçao para mostrar as informações na tela
function mostrarInformaçoes() {
  textsize(16);
  fill(0);
  text("temperatura;" + temperatura.toFixed(2), 10, 30);
  text("arvore plantadas;" + totaldearvores, 10, 50);
  text("para  movimentar o personagem use as setas do teclado", 10, 80);
}

// funçao para verificar se o jogo acabou
function verificarFimdeJogo() {
  if (totalarvores > temperatura) {
    mostrarMensagemdeVitoria();
  } else if (temperatura > 50) {
    mostrarMensagemdederrota();
  }
}

// funçao de mostrar a mensagem de vitoria
function mostrarMensagemdevitoria() {
  textsize(20);
  fill(0, 0, 0);
  text("você venceu! voce plantou muitas arvores! 100, 200");
  noLoop();
}

// funçao mostrar a mensagem de derrota
function verificarmensagemdederrota() {
  textsize(20);
  fill(255, 0, 0);
  text("voce perdeu! a temperatura esta muita alta", 100, 200);
  noLoop();
}

// classe que cria o jardineiro
class jardineiro {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.emoji = "🙎‍♀️";
    this.velolcidade = 3;
  }
}
// Função para atualizar a posição do jardineiro
function atualizar() {
  if (keyIsDown(LEFT_ARROW)) {
    this.x -= this.velocidade;
  }
  if (keyIsDown(RIGHT_ARROW)) {
    this.x += this.velocidade;
  }
  if (keyIsDown(UP_ARROW)) {
    this.y -= this.velocidade;
  }
  if (keyIsDown(DOWN_ARROW)) {
    this.y += this.velocidade;
  }
}

//funçao para desenhar o jardineiro na tela
function mostrar() {
  textsize(32);
  text(this.emoji, this.x, this.y);
}

//funçao para criar  e planar uma arvore
function keyPressed() {
  if (key === "s" || key === "d") {
    let Árvore = new árvore(jardineiro.x, jardineiro.y);
    planta.push(arvore);
    totalarvores++;
    temperatura -= 3;
    if (temperatura < 0) temperaura = 0;
  }
}
